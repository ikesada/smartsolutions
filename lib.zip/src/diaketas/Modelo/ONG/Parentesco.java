/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package diaketas.Modelo.ONG;

import java.util.ArrayList;

/**
 *
 * @author kesada
 */
public class Parentesco {
    /**
     * Tipo del parentesco del familiar
     */
    public String Parentesc;
    
    /*---------------------------Constructores---------------------------------*/
    /**
     * Constructor por parametros.
     * @param Parentesc Tipo de parentesco
     */
    public Parentesco (String Parentesc){
        this.Parentesc = Parentesc;
    }
}
